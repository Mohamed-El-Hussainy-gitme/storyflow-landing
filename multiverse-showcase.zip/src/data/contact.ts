export const CONTACT_EMAIL =
  "https://mail.google.com/mail/?view=cm&fs=1&to=mohamed.noda.b2@gmail.com";


export const CONTACT_EMAIL_RAW = 
  "mohamed.noda.b2@gmail.com";

export const CONTACT_GITHUB = 
  "https://github.com/mohamedzainb2-eng";

export const CONTACT_LINKEDIN = 
  "https://www.linkedin.com/in/mohamed-el-hussainy-b50449399/";


export const CONTACT_WHATSAPP =
  "https://wa.me/201018557413?text=Hi%20Mohamed%2C%20I%20just%20visited%20your%20Storyflow%20Landing%20portfolio%20and%20would%20like%20to%20discuss%20a%20project.";
